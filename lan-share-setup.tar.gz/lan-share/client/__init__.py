"""Lan-Share client package."""
